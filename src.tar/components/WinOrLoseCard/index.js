// Write your code here.

import './index.css'

const WinOrLoseCard = props => {
  const {score, PlayAgain} = props
  const winLoseText = score >= 12 ? 'You Win' : 'You Lose'
  const imgameForResult =
    score >= 12
      ? 'https://assets.ccbp.in/frontend/react-js/won-game-img.png'
      : 'https://assets.ccbp.in/frontend/react-js/lose-game-img.png'
  const onclickedAgain = () => {
    PlayAgain()
  }
  return (
    <div className="card-container">
      <div className="result-score-play-again-container">
        <div className="score-container">
          <p className="win-r-lose">{winLoseText}</p>
          <div className="button-and-score ">
            <p className="score-title">Score</p>
            <p className="score-in-nums">{score}/12</p>
            <button
              type="button"
              onClick={onclickedAgain}
              className="PlayAgainButton"
            >
              PlayAgain
            </button>
          </div>
        </div>
        <div className="image-container">
          <img
            src={imgameForResult}
            alt="result-img"
            className="result-image-with-emojibaloons"
          />
        </div>
      </div>
    </div>
  )
}

export default WinOrLoseCard
