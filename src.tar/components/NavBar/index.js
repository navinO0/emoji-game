// Write your code here.

import './index.css'

const NavBar = props => {
  const {score, maxScore} = props
  return (
    <div className="nav-bar">
      <div className="name-title">
        <img
          src="https://assets.ccbp.in/frontend/react-js/game-logo-img.png"
          alt="emoji logo"
          className="emoji-logo"
        />
        <p className="emoji-game-title">Emoji Game</p>
      </div>
      <div className="score-topScore">
        <p className="score">Score: {score}</p>
        <p className="top-score">Top Score: {maxScore}</p>
      </div>
    </div>
  )
}

export default NavBar
